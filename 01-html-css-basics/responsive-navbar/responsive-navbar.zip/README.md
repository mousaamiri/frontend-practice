#  Responsive Navbar

## Preview

[![Demo Video]](docs/demo.mp4)

### Screenshots

<table>
  <tr>
    <td align="center"><img src="docs/images/light.png" width="100%"/><br/><sub>Light Theme</sub></td>
    <td align="center"><img src="docs/images/dark.png" width="100%"/><br/><sub>Dark Theme</sub></td>
  </tr>

</table>
